class FracDriver{
    public static void main (String[] args) {
        FracClass frac;
        frac = new FracClass("5/678788");
    }
}