public class FracClass{
    private int numerator = 0;
    private int denominator = 0;
    private String Fraction = "";
    private int finalF = 0;
    private int fracNum = 0;
    private int fracDen = 0;
    
    public FracClass() {
        numerator = 1;
        denominator = 1;
    }
    public FracClass(int n, int d) {
        numerator = n;
        denominator = d;
        if (denominator == 0) {
            denominator = 1;
            System.out.println("Sorry you were being a moron so we set your denominator to 1");
        }
        System.out.println(numerator + "/" + denominator);
    }
    public FracClass(String s) {
        Fraction = s;
        if(s.indexOf("/") >= 0 && denominator != 0) {
            numerator = Integer.parseInt(s.substring(0, s.indexOf("/")));
            denominator = Integer.parseInt(s.substring(s.indexOf("/") + 1) );
        } else if (denominator == 0 && s.indexOf("/") >= 0) {
            denominator = 1;
            System.out.println("Sorry you were being a moron so we set your denominator to 1");
        } else {
            System.out.println("Boooooooooooooooooooooo");
        }
        System.out.println(numerator + "/" + denominator);
    }
    public FracClass(FracClass f) {
        numerator = f.numerator;
        denominator = f.denominator; 
    }
    public int getNum() {
        return numerator;
    }
    public int getDen() {
        return denominator;
    }
    public void setNum(int n) {
        numerator = n;
    }
    public void setDen(int d) {
        if (d != 0) {
        denominator = d;
    } else {
        denominator = 1;
        System.out.println("Sorry you were being a moron so we set your denominator to 1");
    }
    }
}