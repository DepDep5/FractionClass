public class FractionDriver {
    public static void main(String[] args) {
        FractionT f1 = new FractionT();
        System.out.println(f1);
        FractionT f2 = new FractionT(2, 3);
        System.out.println(f2);
        FractionT f3 = new FractionT("2/3");
        System.out.println(f3);
        FractionT f4 = new FractionT(f3);
        System.out.println(f4);
    }
}