



/**
 * This is a class that does fraction stuff
 * 
 * @author Grady Chen
 * @version Beta 1.0
 * 
 */
public class FractionT {
    private int num;
    private int den;
    /**
     * Constructor for objects of class FractionT
     */
    public FractionT() {
    }
    /**
     * Overloaded Constructor for objects of class FractionT
     */
    public FractionT (int n, int d) {
        num = n;
        if(d!= 0) {
            den = d;
        } else {
            den = 1;
            System.out.println("bruh");
        }

    }
    /**
     * Overloaded Constructor for objects of class FractionT
     */
    public FractionT(String f) {
        int fwdIndex = f.indexOf("/");
        String numString = f.substring(0, fwdIndex);
        String denString = f.substring(fwdIndex + 1); 
        num = Integer.parseInt(numString); 
        int d = Integer.parseInt(denString);
        if(d!= 0) {
            den = d;
        } else {
            den = 1;
            System.out.println("bruh");
        }
    }

    public FractionT(FractionT f) {
        num = f.num;
        den = f.den;
    }
    /**Mutator method for getting the fraction's numerator
     * @param none
     * @return num
     */
    public int getNumerator() {
        return num;
    }
    /**Mutator method for setting the fraction's denominator
     * @param none
     * @return den
     */
    public int getDenominator() {
        return den;
    }
    
    /**Mutator method for setting the fraction's numerator
     * @param n the int to set the numerator
     * @return nothing
     */
    public void setNumerator(int n) {
        num = n;
    }
    /**Mutator method for setting the fraction's denominator
     * @param n the int to set the denominator
     * @return nothing
     */
    public void setDenominator(int n) {
        if (n != 0) {
            den = n;
        } else {
            den = 1;
            System.out.println("bruh");
        }
    }
    public String toString() {
         return num + "/" + den;
    }
}